library(testthat)
library(multiGSEA)

test_check("multiGSEA")
